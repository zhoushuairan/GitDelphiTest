
# 课程内容

- package、DLL

- winsocket相关

- 注册表操作

- windows服务程序

- 数据库(sqlite)

- 图像压缩相关
  
由Delphi网络基础讲起，最终目标是要实现一个如下图效果的远控软件


<img src="http://imgs.coder163.com//imgsSnipaste_2020-09-06_12-56-02.png" width=300 />


# 资源分享

代码仓库地址：https://github.com/coder163/delphi-socket

哔哩哔哩：https://space.bilibili.com/323024121




# 疑问解答


公众号：Delphi研习社

<img src="http://imgs.coder163.com/gongzhonghao.png" width=120 />


